from .v1 import credit_service_pb2, credit_service_pb2_grpc

__all__ = ['credit_service_pb2', 'credit_service_pb2_grpc']
