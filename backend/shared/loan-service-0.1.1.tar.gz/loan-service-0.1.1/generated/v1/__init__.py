from . import loan_service_pb2, loan_service_pb2_grpc
__all__ = ['loan_service_pb2', 'loan_service_pb2_grpc']
