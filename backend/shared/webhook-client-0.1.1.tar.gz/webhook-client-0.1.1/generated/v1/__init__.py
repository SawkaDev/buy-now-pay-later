from . import webhook_service_pb2, webhook_service_pb2_grpc

__all__ = ['webhook_service_pb2', 'webhook_service_pb2_grpc']
